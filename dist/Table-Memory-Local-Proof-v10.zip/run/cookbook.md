# Table Memory — family cookbook (local rehearsal)

A synthetic proof of the source-linked workflow. Original cards, PDF and voice note remain in `fixtures/`; their SHA-256 fingerprints are in `run/provenance.json`. This is not a UGOS or NAS execution. The local controller reproduced this cookbook from the extracted text; the UGOS Skill did not run.

## How to read this book

- **Source**: read directly from the card, page or transcript.
- **Attributed**: a human recollection, preserved as a recollection, not promoted to fact.
- **Needs review**: the source is unclear, missing or contradictory.

## Jollof Rice — two family branches

| Branch | Source | Oil | Red pepper | Note |
|---|---|---|---|---|
| Mama | `fixtures/jollof-mama.png` | 1/2 cup | present but blurred; no quantity readable; attributed note below | use the big pot; do not rush the pepper |
| Aunty | `fixtures/jollof-aunty.png` | 1/4 cup | 1/2 cup | fry until it separates from the oil |

### Mama

- 2 cups long grain rice — source
- 1/2 cup groundnut oil — source
- 3 tbsp tomato paste — source
- red pepper — **needs review**: the line is present but blurred
- 1 tsp salt — source
- 2 cups stock — source
- Method: fry pepper until dark; add rice; cover — source
- Cook's note: “use the big pot and do not rush the pepper” — source
- Voice note: “For the jollof, Mama always used the big pot. She let the red pepper fry until it darkened, and she never measured the water. She said the rice should drink just enough” — `fixtures/voice-note.mp3`, transcript in `run/voice-transcript.txt`
- Respondent recall: “One cup, blended. Mama used the big pot and added the pepper before the rice.” — **attributed**, not a source value

### Aunty

- 2 cups long grain rice — source
- 1/4 cup groundnut oil — source
- 3 tbsp tomato paste — source
- 1/2 cup red pepper — source
- 1 tsp salt — source
- 2 cups stock — source
- Method: fry pepper longer, then add rice — source
- Cook's note: “fry the pepper until it separates from the oil” — source

The branches are deliberately not merged. The cook chooses which edition to use.

## Coconut Rice

Source: `fixtures/coconut-rice.pdf`, page 1. The source states **yield: 4 servings**.

- 2 cups long grain rice
- 1 cup coconut milk
- 1 cup stock
- 1 small onion
- 1 tsp salt
- 1 tbsp oil
- Method: wash rice; fry onion; add rice, coconut milk, stock and salt; cover and cook on low; rest ten minutes.

### Shopping list — 6 servings

The PDF states 4 servings, so exact scaling is 6/4 = 1.5.

| Ingredient | Original (4) | Scaled (6) |
|---|---:|---:|
| long grain rice | 2 cups | 3 cups |
| coconut milk | 1 cup | 1.5 cups |
| stock | 1 cup | 1.5 cups |
| small onion | 1 | 1.5 small onions (buy 2) |
| salt | 1 tsp | 1.5 tsp |
| oil | 1 tbsp | 1.5 tbsp |

The jollof branches are not included in the scaled list because neither card states a yield. The cook chooses a branch first.

## Provenance index

| Source | SHA-256 |
|---|---|
| `fixtures/jollof-mama.png` | `29d742b22de05b9335b31089e109903d67f5a4c34baf6ca1817c036126642c68` |
| `fixtures/jollof-aunty.png` | `2276ce4eb39db7f8d32f34de74ed98f4619436f53d3d65f8380c196126d8130e` |
| `fixtures/coconut-rice.pdf` | `a1fc593456b8f0b0c838050f68e74af117ed5944001e00fcdb811638c30999ed` |
| `fixtures/voice-note.mp3` | `b51a95e91c91bfc2a7a33b0b73ec3639b2de4115fa658ee9ba6ee77c3c00acc4` |

## Limits of this rehearsal

- OCR was local `tesseract`, not the UGOS photo expert.
- PDF text was local `pdftotext`, not the UGOS document expert.
- The voice was synthetic TTS and was transcribed with ElevenLabs Scribe v2 for rehearsal only; this is not UGOS audio transcription.
- No UGOS delegate, installation, permission prompt, NAS save or read-back was executed.
- The respondent answer is a fixture, not a real family member.
