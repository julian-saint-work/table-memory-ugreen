# Table Memory — review table (local rehearsal)

This is a synthetic local rehearsal, not a UGREEN NAS run. Sources are in `fixtures/`; hashes are in `run/provenance.json`.

## Jollof Rice

| Branch | Source | Oil | Red pepper | Family note | Status |
|---|---|---|---|---|---|
| Mama | `fixtures/jollof-mama.png` | 1/2 cup | line is present but blurred; no quantity readable | use the big pot; do not rush the pepper | `needs_review` |
| Aunty | `fixtures/jollof-aunty.png` | 1/4 cup | 1/2 cup | fry until it separates from the oil | `complete` |

The two versions are kept separately. No ingredient has been averaged or merged.

## One focused question

Mama's card has a red-pepper line that is present but blurred, so the local OCR cannot read its quantity. **How much red pepper did Mama use?**

Allowed answer: a quantity, `I do not know`, or `skip`. A human answer will be recorded as an attributed note, not as a verified card value.

## Coconut Rice

Source: `fixtures/coconut-rice.pdf`; the PDF states **yield: 4 servings**. Scaling to 6 will be shown with the original amount beside the scaled amount. No scaling is claimed for the jollof cards because neither states a yield.
